# Weather-Journal App Project

## Overview
This project has foure faild to do something:
- The first thing is to make to type in it a zip code for that country you want to search for it.
- The second thing is to input your feeling today.
- Third click the button to see your result.
- Finally, you will see the temperature for that country you typed his zip code above, and you see also the date and your feeling.

## Process
### On click the button:
***We have three steps:***
- The first step is get the data from the api 'temp'.
- The second step is put the data into the app by 'POST' method.
- The third step is bring the data by the 'get' method, and show it on the UI page.

