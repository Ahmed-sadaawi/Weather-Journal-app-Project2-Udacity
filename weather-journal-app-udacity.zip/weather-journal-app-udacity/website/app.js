/* Global Variables */
// html Elements;
const feeling= document.getElementById('feelings');
const zip    = document.getElementById('zip');
const apiKey = `33ce008b2b5087d4fa28bc355512dec3`;
// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+1+'.'+ d.getDate()+'.'+ d.getFullYear();
/* End global variables */

/* On click the button //...We have three steps => 
 *     1 => The first step is get the data from the api 'temp';
 *     2 => The second step is put the data into the app by 'POST' method;
 *     3 => The third step is bring 'get' the data and show it on the UI page;
*/

// Event on click the button;
document.getElementById('generate').addEventListener('click', async () => {
  
/* This is the first step "get the data from the api" by the full URL */
    const url=`https://api.openweathermap.org/data/2.5/weather?zip=${zip.value}&appid=${apiKey}&units=metric`; // full url
    // Bring or get the data from the website => 'OpenWeatherMap API'
    const resData = await fetch(url).then(back => back.json());
/* End the first step; */

/* This is the second step "put the data into the app by 'POST' method" */
    await fetch('/add',{ // get the url here and put this data in it; 
        method:'POST', // the method is 'post' 
        headers: {"Content-Type":"application/json"},
        body:JSON.stringify( {temp:resData.main.temp, date:newDate, feeling: feeling.value}) // put this data to the body;
    });
/* End the second step; */   

/* This is the third step "bring the data and show it on the UI page" */
    const allData =await fetch('/all').then(back => back.json());
        document.getElementById('temp').innerHTML = `Temp: ${allData.temp}`;   
        document.getElementById('date').innerHTML = `Date: ${allData.date}`;  
        document.getElementById('content').innerHTML = `Feeling: ${allData.feeling}`;
/* End the third step */
});
//...End the event when click, and the app;
